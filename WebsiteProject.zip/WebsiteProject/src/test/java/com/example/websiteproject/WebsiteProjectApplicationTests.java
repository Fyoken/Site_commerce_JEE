package com.example.websiteproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebsiteProjectApplicationTests {

    @Test
    void contextLoads() {
    }

}

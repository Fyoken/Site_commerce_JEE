package com.example.websiteproject.entities;

public enum Categorie {
    CONSOLE,ACCESSOIRECONSOLE,ACCESSOIREPC,ORDINATEUR,TELEPHONE,JEU
}
